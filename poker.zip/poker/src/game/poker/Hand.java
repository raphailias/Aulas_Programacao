package game.poker;

import java.util.List;

import utilities.Card;

public class Hand {
    private List<Card> cards;
    public Hand(List<Card> cardList){
        cards = cardList;
    }

    public List<Card> getCards() {
        return cards;
    }
}