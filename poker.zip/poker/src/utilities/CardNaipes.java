package utilities;

public enum CardNaipes {
    SPADES, HEARTS, DIAMONDS, CLUBS;
}
