package utilities;

public enum CardValues {
    TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,JACK,KING,ACE;
}
